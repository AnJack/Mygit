package gdcc.maketubo.dto;

public interface poki {

}

package gdcc.maketubo.dto;

public class GameDto {

}

package gdcc.maketubo.service;

public class ImageManager {

}

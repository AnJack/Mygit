package gdcc.maketubo.dto;

public class Record {

}
